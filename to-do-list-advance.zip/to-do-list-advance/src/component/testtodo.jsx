import React, { useEffect, useState } from "react";
import testtodo from "../image/ed-icon.png";
import "../index.css";

const getLocalItems = () => {
    let list = localStorage.getItem('lists');
    console.log(list);

    if(list){
        return JSON.parse(localStorage.getItem('lists'));
    }else{
        return[];
    }
}
const Testtodo = () => {
    const [inptData, setInputData] = useState('');
    const [items, setItems] = useState(getLocalItems());
    // For edit
    const [toggleSubmit, setToggleSubmit] = useState(true);
    const [isEditItem, setIsEditItem] = useState(null);


    const addItem = () =>{
        if(!inptData){
            alert("please fill the data");
        }else if(inptData && !toggleSubmit){
            setItems(
                items.map((elem) => {
                    if(elem.id === isEditItem){
                        return {...elem, name: inptData}
                    }
                    return elem;
                })
            )
            setToggleSubmit(true);
            setInputData('');
            setIsEditItem(null);
        }
        else{
            const allInptData = { id: new Date().getTime().toString(), name:inptData }
            // For edit
            setItems([...items, allInptData]);
            setInputData('')
        }
        
    }
    //delete the items
    const deleteItem = (index) => {
        console.log(index);
        const updateditems = items.filter((elem) => {
            return index !== elem.id;
        });
        setItems(updateditems);
    }
    
    // Edit Items
    const editItem = (id) => {
        let newEditItem = items.find((elem) => {
            return elem.id === id
        });
        console.log(newEditItem);
        setToggleSubmit(false);
        setInputData(newEditItem.name);
        setIsEditItem(id);
    }

    //remove all
    const removeAll = () => {
        setItems([]);
    }

    // add data to local storage
    useEffect(()=>{
        localStorage.setItem('lists', JSON.stringify(items))
    },[items]);
    return(
    <>
       <div className="main-div">
            <div className="child-div">
                <figure>
                    <img src={testtodo} alt="calender" className="myimg"/>
                    <figcaption>Add Your List Here✌️</figcaption>
                </figure>

                <div className="addItems">
                    <input type="text" placeholder="✍️ Add Items.." className="in-add"
                        value={inptData}
                        onChange={(e) => setInputData(e.target.value)}
                    />
                    {
                        toggleSubmit ? <i className="fa-solid fa-plus add-btn" title="Add Item" onClick={addItem}></i> :
                        <i className="fa-solid fa-pen-to-square edit-btn" title="Edit Items" onClick={addItem}></i>
                    }
                </div>

                <div className="showItems">
                    {
                        items.map((elem) => {
                        return(
                            <div className="eachItems" key={elem.id}>
                                <h3>{ elem.name }</h3>
                                <div className="todo-btn">
                                    <i className="fa-solid fa-pen-to-square edit-btn" title="Edit Items" onClick={() => editItem(elem.id)}></i>
                                    <i className="fa-solid fa-trash trash-btn" title="Delete Items" onClick={() => deleteItem(elem.id)}></i>
                                </div>
                            </div>
                            );
                        })
                    }
                </div>
                {/* Clear All Button */}
                <div className="showItems">
                    <button className="btn effect04" data-sm-link-text="Remove All" onClick={removeAll}><span>CHECK LIST</span></button>
                </div>
            </div>
       </div> 
    </>
  );
}
export default Testtodo;