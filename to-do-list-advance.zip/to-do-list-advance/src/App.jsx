import React from "react";
import Testtodo from "./component/testtodo";

const App = () =>{
  return(
    <>
       <Testtodo/>
    </>
  );
}
export default App;